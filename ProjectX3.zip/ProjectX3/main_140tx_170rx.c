/* ========== main.c : 140 MHz TX (Instance 0) + 170 MHz RX (Instance 1) ========== */
/* XDCtools */
#include <xdc/std.h>
#include <xdc/runtime/System.h>

/* BIOS */
#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Task.h>

/* TI-RTOS Drivers */
#include <ti/drivers/GPIO.h>
#include <ti/drivers/SPI.h>

/* TivaWare */
#include "inc/hw_memmap.h"
#include "driverlib/sysctl.h"
#include "driverlib/gpio.h"

/* Board */
#include "Board.h"

/* Radio */
#include <stdint.h>
#include <stddef.h>
#include "cc1200_spi.h"
#include "smartrf_settings_140.h"
#include "smartrf_settings_170.h"

/* ===================== User Configuration ===================== */
#define PKTLEN                  30u     /* Fixed packet length */
#define TX_INTERVAL_MS          100     /* TX packet interval in ms */
#define PERIODIC_SCAL_EVERY     5000    /* Calibrate every N packets */
#define RX_POLL_ATTEMPTS        5       /* RX FIFO check attempts per cycle */
#define DUMP_RX_DEBUG           1       /* Enable RX debug output */

/* ===================== Stacks & Tasks ===================== */
#define STACKSZ_BLINK  512
#define STACKSZ_RADIO  2048

static Task_Struct tBlink_s;
static Char tBlink_stack[STACKSZ_BLINK];
static Task_Struct tRadio_s;
static Char tRadio_stack[STACKSZ_RADIO];

/* ===================== RF Path Pins ===================== */
#define USE_HP_PATH 1

static void init_rf_path_pins(void)
{
    /* Attenuator control: PE0..3 */
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOE);
    while(!SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOE)){}
    GPIOPinTypeGPIOOutput(GPIO_PORTE_BASE, GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3);
    GPIOPinWrite(GPIO_PORTE_BASE, GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3,
                                  GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3);

    /* Attenuator control: PL0..3 */
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOL);
    while(!SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOL)){}
    GPIOPinTypeGPIOOutput(GPIO_PORTL_BASE, GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3);
    GPIOPinWrite(GPIO_PORTL_BASE, GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3,
                                  GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3);

    /* RF path select: PN5 */
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPION);
    while(!SysCtlPeripheralReady(SYSCTL_PERIPH_GPION)){}
    GPIOPinTypeGPIOOutput(GPIO_PORTN_BASE, GPIO_PIN_5);
#if USE_HP_PATH
    GPIOPinWrite(GPIO_PORTN_BASE, GPIO_PIN_5, GPIO_PIN_5);
#else
    GPIOPinWrite(GPIO_PORTN_BASE, GPIO_PIN_5, 0);
#endif
}

/* ===================== Radio Configuration ===================== */
static void applySettingsToInstance(uint8 index)
{
    uint8 writeByte;
    uint16 i;

    cc120xSelectInstance(index);

    /* Reset radio */
    trxSpiCmdStrobe(CC120X_SRES);
    Task_sleep(10);  /* Increased delay after reset */

    /* Apply configuration */
    if(index == 0) {
        /* TX: 140 MHz */
        for(i=0; i<preferredSettings140_count; i++){
            writeByte = preferredSettings140[i].val;
            cc120xSpiWriteReg(preferredSettings140[i].addr, &writeByte, 1);
        }
        System_printf("Applied 140 MHz TX settings\n");
    } else {
        /* RX: 170 MHz */
        for(i=0; i<preferredSettings170_count; i++){
            writeByte = preferredSettings170[i].val;
            cc120xSpiWriteReg(preferredSettings170[i].addr, &writeByte, 1);
        }
        System_printf("Applied 170 MHz RX settings\n");
    }
    System_flush();

    /* Calibrate */
    trxSpiCmdStrobe(CC120X_SCAL);
    Task_sleep(10);
}

static uint32_t verifySettingsOnInstance(uint8 index)
{
    const registerSetting_t* tbl;
    uint16 cnt;
    uint32_t mism = 0;
    uint8 rd = 0;
    uint16 i;

    if(index == 0){
        tbl = preferredSettings140;
        cnt = preferredSettings140_count;
    } else {
        tbl = preferredSettings170;
        cnt = preferredSettings170_count;
    }

    cc120xSelectInstance(index);
    for(i=0; i<cnt; i++){
        rd = 0x00;
        cc120xSpiReadReg(tbl[i].addr, &rd, 1);
        if(rd != tbl[i].val){
            mism++;
            if(mism <= 5){
                System_printf("[CC%u] MISMATCH @0x%04X exp=0x%02X rd=0x%02X\n",
                              (unsigned)index, (unsigned)tbl[i].addr,
                              (unsigned)tbl[i].val, (unsigned)rd);
            }
        }
    }

    if(mism > 0) {
        System_printf("[CC%u] Total mismatches: %lu\n", (unsigned)index, (ULong)mism);
    }
    System_flush();

    return mism;
}

static void configurePacketMode(uint8 index)
{
    uint8 v;
    cc120xSelectInstance(index);

    System_printf("[CC%u] Configuring packet mode (len=%u)...\n", (unsigned)index, PKTLEN);
    System_flush();

    /* Fixed length, no CRC, no whitening, no address filter, no append status */
    v = 0x00;
    cc120xSpiWriteReg(CC120X_PKT_CFG2, &v, 1);
    Task_sleep(1);

    v = 0x00;
    cc120xSpiWriteReg(CC120X_PKT_CFG1, &v, 1);
    Task_sleep(1);

    v = 0x00;
    cc120xSpiWriteReg(CC120X_PKT_CFG0, &v, 1);
    Task_sleep(1);

    v = PKTLEN;
    cc120xSpiWriteReg(CC120X_PKT_LEN, &v, 1);
    Task_sleep(1);

    /* Verify */
    uint8 r2, r1, r0, rl;
    cc120xSpiReadReg(CC120X_PKT_CFG2, &r2, 1);
    cc120xSpiReadReg(CC120X_PKT_CFG1, &r1, 1);
    cc120xSpiReadReg(CC120X_PKT_CFG0, &r0, 1);
    cc120xSpiReadReg(CC120X_PKT_LEN, &rl, 1);

    System_printf("[CC%u] PKT_CFG2=0x%02X PKT_CFG1=0x%02X PKT_CFG0=0x%02X PKT_LEN=%u\n",
                  (unsigned)index, r2, r1, r0, (unsigned)rl);

    if(rl != PKTLEN) {
        System_printf("[CC%u] ERROR: PKT_LEN mismatch! Expected %u, got %u\n",
                      (unsigned)index, PKTLEN, (unsigned)rl);
    }
    System_flush();
}

/* ===================== TX Functions ===================== */
static void makeTxPayload(uint8 *p, uint16 ctr)
{
    /* Sequence number in first 2 bytes */
    p[0] = (uint8)(ctr >> 8);
    p[1] = (uint8)(ctr & 0xFF);

    /* Fill rest with pattern */
    uint8 i;
    for (i=2; i<PKTLEN; i++) {
        p[i] = (uint8)(0xA0 + (i-2));
    }
}

static void transmitPacket(uint8 *txBuf, uint16 pktNum)
{
    cc120xSelectInstance(0);  /* TX instance */

    /* Go to IDLE */
    trxSpiCmdStrobe(CC120X_SIDLE);
    Task_sleep(1);

    /* Flush TX FIFO */
    trxSpiCmdStrobe(CC120X_SFTX);

    /* Write packet to FIFO */
    cc120xSpiWriteTxFifo(txBuf, PKTLEN);

    /* Start transmission */
    trxSpiCmdStrobe(CC120X_STX);

    /* Wait for TX to complete */
    uint8_t txbytes = 0xFF;
    uint8_t marc = 0;
    uint8_t timeout = 50;  /* ~50ms timeout */

    while(timeout--) {
        cc120xSpiReadReg(CC120X_NUM_TXBYTES, &txbytes, 1);
        cc120xSpiReadReg(CC120X_MARCSTATE, &marc, 1);

        /* Check if TX completed (IDLE state) or FIFO empty */
        if((txbytes == 0) || ((marc & 0x1F) == 0x01)) {
            break;
        }

        /* Check for TX FIFO error */
        if((marc & 0x70) == 0x70) {
            System_printf("TX FIFO ERROR detected\n");
            System_flush();
            trxSpiCmdStrobe(CC120X_SFTX);
            return;
        }

        Task_sleep(1);
    }

    if(timeout == 0) {
        System_printf("TX timeout (MARC=0x%02X, bytes=%u)\n", marc, txbytes);
        System_flush();
    }
}

/* ===================== RX Functions ===================== */
static void checkRxRSSI(void)
{
    uint8_t rssi1, rssi0;
    cc120xSelectInstance(1);
    cc120xSpiReadReg(CC120X_RSSI1, &rssi1, 1);
    cc120xSpiReadReg(CC120X_RSSI0, &rssi0, 1);

    System_printf("RX RSSI: raw bytes=0x%02X 0x%02X\n", rssi1, rssi0);
    System_flush();
}

static int rxTryRead(uint8 *rbuf)
{
    uint8 n = 0;
    uint8 marc = 0;

    cc120xSelectInstance(1);
    cc120xSpiReadReg(CC120X_NUM_RXBYTES, &n, 1);
    cc120xSpiReadReg(CC120X_MARCSTATE, &marc, 1);

#if DUMP_RX_DEBUG
    System_printf("[RX] FIFO bytes=%u, MARC=0x%02X (state=%u)\n",
                  (unsigned)n, (unsigned)marc, (unsigned)(marc & 0x1F));
    System_flush();
#endif

    /* Check if we have a full packet */
    if (n < PKTLEN) {
        return 0;
    }

    /* Read packet from FIFO */
    cc120xSpiReadRxFifo(rbuf, PKTLEN);

    return 1;
}

static void ensureRxMode(void)
{
    uint8_t marc = 0;

    cc120xSelectInstance(1);
    cc120xSpiReadReg(CC120X_MARCSTATE, &marc, 1);

    uint8_t state = marc & 0x1F;

    /* Expected RX state is 0x0D */
    if(state != 0x0D) {
        System_printf("RX not in RX mode (state=0x%02X), restarting\n", state);

        /* Check for RXFIFO error */
        if((marc & 0x70) == 0x60) {
            System_printf("RXFIFO ERROR detected\n");
        }
        System_flush();

        /* Restart RX */
        trxSpiCmdStrobe(CC120X_SIDLE);
        Task_sleep(1);
        trxSpiCmdStrobe(CC120X_SFRX);
        Task_sleep(1);
        trxSpiCmdStrobe(CC120X_SRX);
        Task_sleep(2);
    }
}

/* ===================== Radio Task ===================== */
static Void RadioTask(UArg a0, UArg a1)
{
    (void)a0; (void)a1;

    uint16_t txCtr = 0;
    uint16_t rxCtr = 0;
    uint8_t  txBuf[PKTLEN];
    uint8_t  rxBuf[PKTLEN];

    System_printf("\n=== CC1200 Dual Radio Init ===\n");
    System_flush();

    /* Initialize RF path */
    init_rf_path_pins();

    /* Initialize SPI */
    cc120xSpiInit();
    Task_sleep(50);

    /* Configure TX radio (Instance 0: 140 MHz) */
    System_printf("\n--- Configuring TX Radio (140 MHz) ---\n");
    applySettingsToInstance(0);
    configurePacketMode(0);
    verifySettingsOnInstance(0);

    /* Configure RX radio (Instance 1: 170 MHz) */
    System_printf("\n--- Configuring RX Radio (170 MHz) ---\n");
    applySettingsToInstance(1);
    configurePacketMode(1);
    verifySettingsOnInstance(1);

    /* Start RX mode */
    System_printf("\nStarting RX mode...\n");
    System_flush();
    cc120xSelectInstance(1);
    trxSpiCmdStrobe(CC120X_SFRX);
    Task_sleep(2);
    trxSpiCmdStrobe(CC120X_SRX);
    Task_sleep(10);

    /* Check initial RX RSSI */
    checkRxRSSI();

    System_printf("\n=== Starting TX/RX Loop ===\n");
    System_flush();

    /* Main loop */
    for(;;) {
        /* Periodic calibration */
        if ((txCtr % PERIODIC_SCAL_EVERY) == 0 && txCtr > 0) {
            System_printf("Performing periodic calibration...\n");
            System_flush();

            cc120xSelectInstance(0);
            trxSpiCmdStrobe(CC120X_SIDLE);
            trxSpiCmdStrobe(CC120X_SCAL);
            Task_sleep(10);

            cc120xSelectInstance(1);
            trxSpiCmdStrobe(CC120X_SIDLE);
            trxSpiCmdStrobe(CC120X_SCAL);
            Task_sleep(10);
            trxSpiCmdStrobe(CC120X_SRX);
            Task_sleep(5);
        }

        /* ===== TRANSMIT PACKET ===== */
        makeTxPayload(txBuf, txCtr);
        transmitPacket(txBuf, txCtr);

        System_printf("TX #%u sent\n", (unsigned)txCtr);
        System_flush();
        txCtr++;

        /* Small delay for radio to switch and packet to propagate */
        Task_sleep(10);

        /* ===== RECEIVE PACKETS ===== */
        ensureRxMode();

        /* Try to read available packets */
        int attempts;
        for(attempts = 0; attempts < RX_POLL_ATTEMPTS; attempts++) {
            if (rxTryRead(rxBuf)) {
                /* Extract sequence number */
                uint16 seq = ((uint16)rxBuf[0] << 8) | rxBuf[1];

                System_printf("RX #%u: seq=%u, data=[%02X %02X %02X %02X...]\n",
                              (unsigned)rxCtr, (unsigned)seq,
                              rxBuf[0], rxBuf[1], rxBuf[2], rxBuf[3]);
                System_flush();

                rxCtr++;
            } else {
                break;  /* No more packets in FIFO */
            }
            Task_sleep(1);
        }

        /* Check RSSI periodically */
        if((txCtr % 50) == 0) {
            checkRxRSSI();
        }

        /* Wait before next TX */
        Task_sleep(TX_INTERVAL_MS);
    }
}

/* ===================== Blink Task ===================== */
static Void BlinkTask(UArg a0, UArg a1)
{
    (void)a0; (void)a1;

    for(;;){
        GPIO_write(Board_LED0, Board_LED_ON);
        Task_sleep(500);
        GPIO_write(Board_LED0, Board_LED_OFF);
        Task_sleep(500);
    }
}

/* ===================== main() ===================== */
int main(void)
{
    /* Initialize board */
    Board_initGeneral();
    Board_initGPIO();
    Board_initSPI();

    /* Create blink task */
    Task_Params blinkParams;
    Task_Params_init(&blinkParams);
    blinkParams.stack = tBlink_stack;
    blinkParams.stackSize = sizeof(tBlink_stack);
    blinkParams.priority = 1;
    blinkParams.instance->name = (xdc_String)"blink";
    Task_construct(&tBlink_s, (Task_FuncPtr)BlinkTask, &blinkParams, NULL);

    /* Create radio task */
    Task_Params radioParams;
    Task_Params_init(&radioParams);
    radioParams.stack = tRadio_stack;
    radioParams.stackSize = sizeof(tRadio_stack);
    radioParams.priority = 2;
    radioParams.instance->name = (xdc_String)"radio_140tx_170rx";
    Task_construct(&tRadio_s, (Task_FuncPtr)RadioTask, &radioParams, NULL);

    /* Start BIOS */
    BIOS_start();

    return 0;
}
