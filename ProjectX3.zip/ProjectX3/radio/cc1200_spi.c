#include "cc1200_spi.h"
#include <ti/drivers/SPI.h>
#include "EK_TM4C1294XL.h"
#include <driverlib/gpio.h>
#include <string.h>
#include "inc/hw_memmap.h"
#include "driverlib/sysctl.h"

static SPI_Handle s_spiHandles[2] = { NULL, NULL };;
static uint8 s_activeIndex = 0; /* 0: SSI1 (TX), 1: SSI3 (RX) */
static uint8 s_txBuf[2 + 255];
static uint8 s_rxBuf[2 + 255];

static void cs_high(void)
{
  if(s_activeIndex == 0) {
    GPIOPinWrite(GPIO_PORTB_BASE, GPIO_PIN_4, GPIO_PIN_4);
  } else {
    GPIOPinWrite(GPIO_PORTQ_BASE, GPIO_PIN_1, GPIO_PIN_1);
  }
}

static void cs_low(void)
{
  if(s_activeIndex == 0) {
    GPIOPinWrite(GPIO_PORTB_BASE, GPIO_PIN_4, 0);
  } else {
    GPIOPinWrite(GPIO_PORTQ_BASE, GPIO_PIN_1, 0);
  }
}

void cc120xSpiInit(void)
{
  SPI_Params params;
  SPI_Params_init(&params);
  params.frameFormat = SPI_POL0_PHA0;
  params.mode        = SPI_MASTER;
  params.bitRate     = 4000000; /* 4 MHz */
  params.dataSize    = 8;

  if (s_spiHandles[0] == NULL) {
    s_spiHandles[0] = SPI_open(EK_TM4C1294XL_SPI1, &params);
  }
  if (s_spiHandles[1] == NULL) {
    s_spiHandles[1] = SPI_open(EK_TM4C1294XL_SPI3, &params);
  }

  SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOH);
  SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOK);
  SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOB);
  SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOQ);
  while(!SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOH));
  while(!SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOK));
  while(!SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOB));
  while(!SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOQ));

  GPIOPinTypeGPIOOutput(GPIO_PORTH_BASE, GPIO_PIN_2);  /* PH2 uC_TX_CC_PWR_EN   */
  GPIOPinTypeGPIOOutput(GPIO_PORTH_BASE, GPIO_PIN_3);  /* PH3 uC_TX_AMP_PWR_EN  */
  GPIOPinTypeGPIOOutput(GPIO_PORTK_BASE, GPIO_PIN_5);  /* PK5 uC_RX_CC_PWR_EN   */
  GPIOPinTypeGPIOOutput(GPIO_PORTB_BASE, GPIO_PIN_2);  /* PB2 uC_GNSS_PWR_EN    */

  GPIOPinTypeGPIOOutput(GPIO_PORTB_BASE, GPIO_PIN_4);  /* PB4 = CS (TX) */
  GPIOPinTypeGPIOOutput(GPIO_PORTQ_BASE, GPIO_PIN_1);  /* PQ1 = CS (RX) */
  GPIOPinWrite(GPIO_PORTB_BASE, GPIO_PIN_4, GPIO_PIN_4);
  GPIOPinWrite(GPIO_PORTQ_BASE, GPIO_PIN_1, GPIO_PIN_1);

  GPIOPinWrite(GPIO_PORTH_BASE, GPIO_PIN_2, GPIO_PIN_2); /* TX enable (1) */
  GPIOPinWrite(GPIO_PORTH_BASE, GPIO_PIN_3, GPIO_PIN_3);
  GPIOPinWrite(GPIO_PORTK_BASE, GPIO_PIN_5, GPIO_PIN_5); /* RX enable (1) */
  GPIOPinWrite(GPIO_PORTB_BASE, GPIO_PIN_2, GPIO_PIN_2);
}


void cc120xSelectInstance(uint8 index)
{
  s_activeIndex = (index ? 1 : 0);
}

static inline SPI_Handle activeSpi(void)
{
  return s_spiHandles[s_activeIndex];
}

/*
 * The CC120x requires checking CHIP_RDYn via MISO low before first byte. With
 * TI-RTOS SPI we cannot poll MISO easily, so we poll by issuing dummy SNOPs
 * and checking returned status until STATUS_CHIP_RDYn_BM clears.
 */
static uint8 trxPollReady(void)
{
  uint8 cmd = CC120X_SNOP;
  uint8 sts = 0xFF;
  SPI_Transaction t;
  memset(&t, 0, sizeof(t));
  t.count = 1;
  t.txBuf = &cmd;
  t.rxBuf = &sts;
  uint32 i;
  for(i = 0; i < 1000; i++)
  {
    cs_low();
    if(SPI_transfer(activeSpi(), &t))
    {
      if((sts & STATUS_CHIP_RDYn_BM) == 0){
          cs_high();
          return sts;
      }
    }
    cs_high();
  }
  return sts;
}

rfStatus_t trxSpiCmdStrobe(uint8 cmd)
{
  uint8 tx = cmd;
  uint8 rx = 0xFF;
  SPI_Transaction t;
  (void)trxPollReady();
  memset(&t, 0, sizeof(t));
  t.count = 1;
  t.txBuf = &tx;
  t.rxBuf = &rx;
  cs_low();
  if(SPI_transfer(activeSpi(), &t)){
      cs_high();
      return rx;
  }
  cs_high();
  return rx;
}

rfStatus_t trx8BitRegAccess(uint8 accessType, uint8 addressByte, uint8 *pData, uint8 len)
{
  uint8 hdr = (uint8)(accessType | (addressByte & 0x3F));
  rfStatus_t status = 0xFF;
  SPI_Transaction t;
  (void)trxPollReady();
  if(accessType & RADIO_READ_ACCESS)
  {
    uint8 *txBuf = s_txBuf;
    uint8 *rxBuf = s_rxBuf;
    txBuf[0] = hdr;
    uint8 i;
    for(i = 0; i < len; i++) txBuf[1 + i] = 0x00;
    memset(&t, 0, sizeof(t));
    t.count = (size_t)(1 + len);
    t.txBuf = txBuf;
    t.rxBuf = rxBuf;
    cs_low();
    if(SPI_transfer(activeSpi(), &t))
    {
      status = rxBuf[0];
      uint8 i;
      for(i = 0; i < len; i++) pData[i] = rxBuf[1 + i];
    }
    cs_high();
  }
  else
  {
    uint8 *txBuf = s_txBuf;
    uint8 *rxBuf = s_rxBuf;
    txBuf[0] = hdr;
    uint8 i;
    for(i = 0; i < len; i++) txBuf[1 + i] = pData[i];
    memset(&t, 0, sizeof(t));
    t.count = (size_t)(1 + len);
    t.txBuf = txBuf;
    t.rxBuf = rxBuf;
    cs_low();
    if(SPI_transfer(activeSpi(), &t))
    {
      status = rxBuf[0];
    }
    cs_high();
  }
  return status;
}

rfStatus_t trx16BitRegAccess(uint8 accessType, uint8 extAddress, uint8 regAddress, uint8 *pData, uint8 len)
{
  rfStatus_t status = 0xFF;
  uint8 ext = (uint8)(accessType | (extAddress & 0xFF));
  uint8 addr = regAddress;
  SPI_Transaction t;
  (void)trxPollReady();
  if(accessType & RADIO_READ_ACCESS)
  {
    uint8 *txBuf = s_txBuf;
    uint8 *rxBuf = s_rxBuf;
    txBuf[0] = ext;
    txBuf[1] = addr;
    uint8 i;
    for(i = 0; i < len; i++) txBuf[2 + i] = 0x00;
    memset(&t, 0, sizeof(t));
    t.count = (size_t)(2 + len);
    t.txBuf = txBuf;
    t.rxBuf = rxBuf;
    cs_low();
    if(SPI_transfer(activeSpi(), &t))
    {
      status = rxBuf[0];
      uint8 i;
      for(i = 0; i < len; i++) pData[i] = rxBuf[2 + i];
    }
    cs_high();
  }
  else
  {
    uint8 *txBuf = s_txBuf;
    uint8 *rxBuf = s_rxBuf;
    txBuf[0] = ext;
    txBuf[1] = addr;
    uint8 i;
    for(i = 0; i < len; i++) txBuf[2 + i] = pData[i];
    memset(&t, 0, sizeof(t));
    t.count = (size_t)(2 + len);
    t.txBuf = txBuf;
    t.rxBuf = rxBuf;
    cs_low();
    if(SPI_transfer(activeSpi(), &t))
    {
      status = rxBuf[0];
    }
    cs_high();
  }
  return status;
}

/******************************************************************************
 * @fn          cc120xSpiReadReg
 *
 * @brief       Read value(s) from config/status/extended radio register(s).
 *              If len  = 1: Reads a single register
 *              if len != 1: Reads len register values in burst mode
 *
 * input parameters
 *
 * @param       addr   - address of first register to read
 * @param       *pData - pointer to data array where read bytes are saved
 * @param       len   - number of bytes to read
 *
 * output parameters
 *
 * @return      rfStatus_t
 */
rfStatus_t cc120xSpiReadReg(uint16 addr, uint8 *pData, uint8 len)
{
  uint8 tempExt  = (uint8)(addr>>8);
  uint8 tempAddr = (uint8)(addr & 0x00FF);
  uint8 rc;

  /* Checking if this is a FIFO access -> returns chip not ready  */
  if((CC120X_SINGLE_TXFIFO<=tempAddr)&&(tempExt==0)) return STATUS_CHIP_RDYn_BM;

  /* Decide what register space is accessed */
  if(!tempExt)
  {
    rc = trx8BitRegAccess((RADIO_BURST_ACCESS|RADIO_READ_ACCESS),tempAddr,pData,len);
  }
  else if (tempExt == 0x2F)
  {
    rc = trx16BitRegAccess((RADIO_BURST_ACCESS|RADIO_READ_ACCESS),tempExt,tempAddr,pData,len);
  }
  return (rc);
}

/******************************************************************************
 * @fn          cc120xSpiWriteReg
 *
 * @brief       Write value(s) to config/status/extended radio register(s).
 *              If len  = 1: Writes a single register
 *              if len  > 1: Writes len register values in burst mode
 *
 * input parameters
 *
 * @param       addr   - address of first register to write
 * @param       *pData - pointer to data array that holds bytes to be written
 * @param       len    - number of bytes to write
 *
 * output parameters
 *
 * @return      rfStatus_t
 */
rfStatus_t cc120xSpiWriteReg(uint16 addr, uint8 *pData, uint8 len)
{
  uint8 tempExt  = (uint8)(addr>>8);
  uint8 tempAddr = (uint8)(addr & 0x00FF);
  uint8 rc;

  /* Checking if this is a FIFO access - returns chip not ready */
  if((CC120X_SINGLE_TXFIFO<=tempAddr)&&(tempExt==0)) return STATUS_CHIP_RDYn_BM;

  /* Decide what register space is accessed */
  if(!tempExt)
  {
    rc = trx8BitRegAccess((RADIO_BURST_ACCESS|RADIO_WRITE_ACCESS),tempAddr,pData,len);
  }
  else if (tempExt == 0x2F)
  {
    rc = trx16BitRegAccess((RADIO_BURST_ACCESS|RADIO_WRITE_ACCESS),tempExt,tempAddr,pData,len);
  }
  return (rc);
}

rfStatus_t cc120xSpiWriteTxFifo(uint8 *pWriteData, uint8 len)
{
  return trx8BitRegAccess(RADIO_BURST_ACCESS | RADIO_WRITE_ACCESS, (uint8)CC120X_BURST_TXFIFO, pWriteData, len);
}

rfStatus_t cc120xSpiReadRxFifo(uint8 *pReadData, uint8 len)
{
  return trx8BitRegAccess(RADIO_BURST_ACCESS | RADIO_READ_ACCESS, (uint8)CC120X_BURST_RXFIFO, pReadData, len);
}

rfStatus_t cc120xGetTxStatus(void)
{
  return trxSpiCmdStrobe(CC120X_SNOP);
}

rfStatus_t cc120xGetRxStatus(void)
{
  return trxSpiCmdStrobe(CC120X_SNOP);
}
