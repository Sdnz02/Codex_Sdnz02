/* XDCtools */
#include <xdc/std.h>
#include <xdc/runtime/System.h>

/* BIOS */
#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Task.h>
#include <ti/sysbios/knl/Clock.h>

/* TI-RTOS Drivers */
#include <ti/drivers/GPIO.h>
#include <ti/drivers/SPI.h>

/* TivaWare */
#include "inc/hw_memmap.h"
#include "driverlib/sysctl.h"
#include "driverlib/gpio.h"

/* Board */
#include "Board.h"

/* Radio */
#include <stdint.h>
#include <stddef.h>
#include "cc1200_spi.h"
#include "smartrf_settings_140.h"

#define STACKSZ_BLK         1024
#define PKTLEN_TX           30u
#define USE_HP_PATH         0

static Task_Struct tBlink_s;  static Char tBlink_stack[STACKSZ_BLK];
static Task_Struct tRadio_s;  static Char tRadio_stack[STACKSZ_BLK];

static Void BlinkTask(UArg a0, UArg a1){
    (void)a0; (void)a1;
    for(;;){
        GPIO_write(Board_LED0, Board_LED_ON);  Task_sleep(250);
        GPIO_write(Board_LED0, Board_LED_OFF); Task_sleep(250);
    }
}

static void applySettingsToInstance(uint8 index)
{
    uint8 writeByte;
    cc120xSelectInstance(index);
    trxSpiCmdStrobe(CC120X_SRES); // Reset the CC1200
    Task_sleep(1);

    if(index == 0){
        uint16 i;
        for(i=0;i<preferredSettings140_count;i++){
            writeByte = preferredSettings140[i].val;
            cc120xSpiWriteReg(preferredSettings140[i].addr, &writeByte, 1);
        }
    }
}

static uint32_t verifySettingsOnInstance(uint8 index)
{
    uint8 rd = 0;
    uint32_t mismatches = 0;
    if(index == 0){
        uint16 i;
        cc120xSelectInstance(0);
        for(i=0;i<preferredSettings140_count;i++){
            rd = 0x00;
            cc120xSpiReadReg(preferredSettings140[i].addr, &rd, 1);
            if(rd != preferredSettings140[i].val){
                mismatches++;
                if(mismatches <= 8){
                    System_printf("Idx%u: 0x%04x exp=0x%02x rd=0x%02x\n",
                                  (unsigned)index,
                                  (unsigned)preferredSettings140[i].addr,
                                  (unsigned)preferredSettings140[i].val,
                                  (unsigned)rd);
                }
            }
        }
    }
    return mismatches;
}

static void init_rf_path_pins(void)
{
    // Atenuator pins (PL0, PL1, PL2, PL3)
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOL);
    while(!SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOL)){}
    GPIOPinTypeGPIOOutput(GPIO_PORTL_BASE, GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3);
    GPIOPinWrite(GPIO_PORTL_BASE, GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3,
                                  GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3);

    // RF Pin (PN5)
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPION);
    while(!SysCtlPeripheralReady(SYSCTL_PERIPH_GPION)){}
    GPIOPinTypeGPIOOutput(GPIO_PORTN_BASE, GPIO_PIN_5);

#if USE_HP_PATH
    GPIOPinWrite(GPIO_PORTN_BASE, GPIO_PIN_5, GPIO_PIN_5); // For RF1 path PN5 needs to be high
#else
    GPIOPinWrite(GPIO_PORTN_BASE, GPIO_PIN_5, 0); // For RF2 path
#endif
}

static void makePacket(uint8* tx, uint16 ctr)
{
    uint8 i;
    tx[0] = (uint8)PKTLEN_TX;
    tx[1] = (uint8)(ctr >> 8);
    tx[2] = (uint8)(ctr & 0xFF);
    for(i=3;i<(PKTLEN_TX+1u);i++){
        tx[i] = (uint8)(0xA0u + (uint8)(i-3u));
    }
}

static Void RadioTask(UArg a0, UArg a1)
{
    (void)a0; (void)a1;

    uint16_t pktCtr = 0;
    uint8_t  txBuf[PKTLEN_TX + 1u];
    uint8_t  txbytes = 0u, marc = 0u;

    init_rf_path_pins();
    cc120xSpiInit();

    applySettingsToInstance(0); // 0 for 140, 1 for 170
    System_printf("CC1200[140-TX] mismatches: %lu\n", (ULong)verifySettingsOnInstance(0));
    System_flush();
    cc120xSelectInstance(0);
    for(;;){
        makePacket(txBuf, pktCtr++);
        if ((pktCtr % 5000) == 1) {
             trxSpiCmdStrobe(CC120X_SIDLE);
             trxSpiCmdStrobe(CC120X_SCAL);
             Task_sleep(1);
        }

        trxSpiCmdStrobe(CC120X_SIDLE);
        trxSpiCmdStrobe(CC120X_SFTX);

        cc120xSpiWriteTxFifo(txBuf, sizeof(txBuf));

        trxSpiCmdStrobe(CC120X_STX);

        do{
            cc120xSpiReadReg(CC120X_NUM_TXBYTES, &txbytes, 1);
            cc120xSpiReadReg(CC120X_MARCSTATE,   &marc,    1);
            Task_sleep(1);
        }while((txbytes != 0u) && ((marc & 0x1Fu) == 0x13u)); /* 0x13=TX */

        uint8_t finalState = marc & 0x1Fu;
        if (finalState == 0x70) { // 0x70 = TXFIFO_ERROR
            System_printf("\nFATAL: TX FIFO Error! Attempting recovery...\n");
            System_flush();
            trxSpiCmdStrobe(CC120X_SFTX);
        }

        if((pktCtr % 1000u) == 0u){
            System_printf("\n140MHz TX sent: %u (MARCSTATE: 0x%02x)\n", (unsigned)pktCtr, finalState);
            System_flush();
        }
        if((pktCtr % 100u) == 0u){
             System_printf(".");
             System_flush();
        }
    }
}

int main(void)
{
    Board_initGeneral();
    // Board_initEMAC();
    Board_initGPIO();
    // Board_initI2C();
    // Board_initSDSPI();
    Board_initSPI();
    // Board_initUART();
    // Board_initUSB(Board_USBDEVICE);
    // Board_initUSBMSCHFatFs();
    // Board_initWatchdog();
    // Board_initWiFi();

    { Task_Params p; Task_Params_init(&p);
      p.stack = tBlink_stack; p.stackSize = STACKSZ_BLK; p.priority = 1;
      p.instance->name = (xdc_String)"blink";
      Task_construct(&tBlink_s, (Task_FuncPtr)BlinkTask, &p, NULL);
    }

    { Task_Params p; Task_Params_init(&p);
      p.stack = tRadio_stack; p.stackSize = STACKSZ_BLK; p.priority = 2;
      p.instance->name = (xdc_String)"radio_tx_140";
      Task_construct(&tRadio_s, (Task_FuncPtr)RadioTask, &p, NULL);
    }

    BIOS_start();

    return 0;
}
