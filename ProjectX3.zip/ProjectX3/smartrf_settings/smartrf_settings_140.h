#ifndef SMARTRF_SETTINGS_140_H_
#define SMARTRF_SETTINGS_140_H_

#include "cc1200_spi.h"

/* Base settings cloned from SmartrfSettings_config.h and adjusted for 140 MHz */
static const registerSetting_t preferredSettings140[]= {
    {CC120X_IOCFG2,         0x06},
    {CC120X_DEVIATION_M,    0xD1},
    {CC120X_MODCFG_DEV_E,   0x00},
    {CC120X_DCFILT_CFG,     0x5D},
    {CC120X_PREAMBLE_CFG0,  0x8A},
    {CC120X_IQIC,           0xCB},
    {CC120X_CHAN_BW,        0xA6},
    {CC120X_MDMCFG1,        0x40},
    {CC120X_MDMCFG0,        0x05},
    {CC120X_SYMBOL_RATE2,   0x3F},
    {CC120X_SYMBOL_RATE1,   0x75},
    {CC120X_SYMBOL_RATE0,   0x10},
    {CC120X_AGC_REF,        0x20},
    {CC120X_AGC_CS_THR,     0xEC},
    {CC120X_AGC_CFG1,       0x51},
    {CC120X_AGC_CFG0,       0x87},
    {CC120X_FIFO_CFG,       0x00},
    {CC120X_FS_CFG,         0x1B},
    {CC120X_PKT_CFG2,       0x00},
    {CC120X_PKT_CFG1,       0x00},
    {CC120X_PKT_CFG0,       0x00},
    {CC120X_PKT_LEN,        30},
    {CC120X_IF_MIX_CFG,     0x1C},
    {CC120X_FREQOFF_CFG,    0x22},
    {CC120X_MDMCFG2,        0x0C},
    {CC120X_FREQ2,          0x54},
    {CC120X_FREQ1,          0x00},
    {CC120X_FREQ0,          0x00},
    {CC120X_IF_ADC1,        0xEE},
    {CC120X_IF_ADC0,        0x10},
    {CC120X_FS_DIG1,        0x07},
    {CC120X_FS_DIG0,        0xAF},
    {CC120X_FS_CAL1,        0x40},
    {CC120X_FS_CAL0,        0x0E},
    {CC120X_FS_DIVTWO,      0x03},
    {CC120X_FS_DSM0,        0x33},
    {CC120X_FS_DVC0,        0x17},
    {CC120X_FS_PFD,         0x00},
    {CC120X_FS_PRE,         0x6E},
    {CC120X_FS_REG_DIV_CML, 0x1C},
    {CC120X_FS_SPARE,       0xAC},
    {CC120X_FS_VCO0,        0xB5},
    {CC120X_XOSC5,          0x0E},
    {CC120X_XOSC1,          0x03},
    };

static const uint16 preferredSettings140_count = (uint16)(sizeof(preferredSettings140)/sizeof(preferredSettings140[0]));

#endif /* SMARTRF_SETTINGS_140_H_ */


